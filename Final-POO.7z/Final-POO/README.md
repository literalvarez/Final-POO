Parcial 1 POO
