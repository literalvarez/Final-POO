package clases;

public class FichaTecnica 
{
	static String TipoDeMotor;
	static int Puertas;
	static int Cilindraje;
	static String Traccion;
	static String TipoDeDireccion;
	static int NumCambios;
	static int IDFichaT;

	public static void FichaA1()
	{
		String TipoDeMotor = "Gasolina";
		int Puertas = 5;
		int Cilindraje = 3000;
		String Traccion = "4x4";
		String TipoDeDireccion = "Electronica";
		int NumCambios = 8;
		int IDFichaT = 808635;
		
		System.out.println("===============FICHA TECNINCA===============");
		System.out.println("Tipo de motor:" + TipoDeMotor);
		System.out.println("Numero de puertas:" + Puertas);
		System.out.println("Cilindraje:" + Cilindraje);
		System.out.println("Traccion:" + Traccion);
		System.out.println("Tipo de direccion:" + TipoDeDireccion);
		System.out.println("Numero de cambios:" + NumCambios);
		System.out.println("Identificacion de la ficha:" + IDFichaT);
		System.out.println("============================================");
	}
	
	public static void FichaA2()
	{
		String TipoDeMotor = "Gasolina";
		int Puertas = 2;
		int Cilindraje = 3000;
		String Traccion = "Delantera";
		String TipoDeDireccion = "Electronica";
		int NumCambios = 10;
		int IDFichaT = 326535;
		
		System.out.println("===============FICHA TECNINCA===============");
		System.out.println("Tipo de motor:" + TipoDeMotor);
		System.out.println("Numero de puertas:" + Puertas);
		System.out.println("Cilindraje:" + Cilindraje);
		System.out.println("Traccion:" + Traccion);
		System.out.println("Tipo de direccion:" + TipoDeDireccion);
		System.out.println("Numero de cambios:" + NumCambios);
		System.out.println("Identificacion de la ficha:" + IDFichaT);
		System.out.println("============================================");
	}
	public static void FichaB1()
	{
		String TipoDeMotor = "Diesel";
		int Puertas = 5;
		int Cilindraje = 2500;
		String Traccion = "Delantera";
		String TipoDeDireccion = "Electronica";
		int NumCambios = 6;
		int IDFichaT = 523547;
		System.out.println("===============FICHA TECNINCA===============");
		System.out.println("Tipo de motor:" + TipoDeMotor);
		System.out.println("Numero de puertas:" + Puertas);
		System.out.println("Cilindraje:" + Cilindraje);
		System.out.println("Traccion:" + Traccion);
		System.out.println("Tipo de direccion:" + TipoDeDireccion);
		System.out.println("Numero de cambios:" + NumCambios);
		System.out.println("Identificacion de la ficha:" + IDFichaT);
		System.out.println("============================================");
	}
	public static void FichaB2()
	{
		String TipoDeMotor = "Diesel";
		int Puertas = 3;
		int Cilindraje = 3000;
		String Traccion = "Delantera";
		String TipoDeDireccion = "Hydraulica";
		int NumCambios = 6;
		int IDFichaT = 355523;
		
		System.out.println("===============FICHA TECNINCA===============");
		System.out.println("Tipo de motor:" + TipoDeMotor);
		System.out.println("Numero de puertas:" + Puertas);
		System.out.println("Cilindraje:" + Cilindraje);
		System.out.println("Traccion:" + Traccion);
		System.out.println("Tipo de direccion:" + TipoDeDireccion);
		System.out.println("Numero de cambios:" + NumCambios);
		System.out.println("Identificacion de la ficha:" + IDFichaT);
		System.out.println("============================================");
	}
	
}
