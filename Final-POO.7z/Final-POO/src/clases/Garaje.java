package clases;

public class Garaje {
	
	static String IDGaraje;
	
	public static void A01() 
	{
		
		IDGaraje = "A01";
	}
	
	public static void A02() 
	{
		IDGaraje = "A02";
	}

	public static void B01() 
	{
		IDGaraje = "B01";
	}
	
	public static void B02() 
	{
		IDGaraje = "B02";
	}
}
