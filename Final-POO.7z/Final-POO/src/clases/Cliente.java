package clases;
import java.util.Scanner;

public class Cliente 
{
	static Scanner scanner = new Scanner(System.in);
	
	static String Nombre;
	static int Cedula;		
	static String Direccion;
	static int Telefono;
	static int Edad;
	static int ContadorID;
	static boolean Refereneciado;
	static int ReservasCliente;
	static int IDCliente;

	public Cliente() 
	{
		Nombre = "";
		Cedula = 0;
		Direccion = "";
		Telefono = 0;
		Edad =0 ;
		ContadorID = 0;
		Refereneciado = false;
		ReservasCliente = 0;
		IDCliente = 0;
	}
	public static void Registro() 
	{
		
		System.out.println("");
		System.out.println("==================================");
		System.out.println("============REGISTRO==============");
		System.out.println("==================================");
		System.out.println("");
		
		System.out.println("Escriba su edad");
		Edad = Integer.parseInt(scanner.nextLine());
		
		if (Edad >= 18)
		{
			System.out.println("Escriba su nombre completo");
			Nombre = scanner.nextLine();
			
			System.out.println("Escriba su numero de cedula");
			Cedula = Integer.parseInt(scanner.nextLine());
			
			System.out.println("Escriba su direccion");
			Direccion = scanner.nextLine();
			
			System.out.println("Escriba su numero de telefono");
			Telefono = Integer.parseInt(scanner.nextLine());
			
			IDCliente = ContadorID+11;
			
			System.out.println("Eres referenciado? Escriba true o false");
			 boolean Referenciado = scanner.nextBoolean();  
			
	        System.out.println("");
	   		System.out.println("=======REGISTRO COMPLETADO=======");
	   		System.out.println("");
	   		System.out.println("Nombre:       " + Nombre);
	   		System.out.println("Edad:         " + Edad);
	   		System.out.println("Cedula:       " + Cedula);
	   		System.out.println("Direccion     " + Direccion);
	   		System.out.println("Telefono:     " + Telefono);
	   		System.out.println("ID de cliente:" + IDCliente);
	   		System.out.println("Reservas:     " + ReservasCliente);
	   		if (Referenciado == true) 
	           {  
	               System.out.println("Referenciado");  
	           } else if (Referenciado == false) 
	           {  
	               System.out.println("No es referenciado");  
	           }
	   		System.out.println("");
	   		System.out.println("===REGRESANDO AL MENU PRINCIPAL===");
	   		System.out.println("");
	   		System.out.println("");
			
		}
		
		if (Edad < 18)
			
		{
		System.out.println("");
		System.out.println("==================================");
		System.out.println("=======EDAD MINIMIA 18 A�OS=======");
		System.out.println("==================================");
		System.out.println("");
   		System.out.println("===REGRESANDO AL MENU PRINCIPAL===");
   		System.out.println("");		
		}
				
	}
	
	public static void InfoCliente() 
	{
		System.out.println("");
   		System.out.println("=====INFORMACION CLIENTE======");
   		System.out.println("");
   		System.out.println("Nombre:       " + Nombre);
   		System.out.println("Edad:         " + Edad);
   		System.out.println("Cedula:       " + Cedula);
   		System.out.println("Direccion     " + Direccion);
   		System.out.println("Telefono:     " + Telefono);
   		System.out.println("ID de cliente:" + IDCliente);
   		System.out.println("Reservas:     " + ReservasCliente);
   		System.out.println("");
	}
}
