package clases;
import java.util.Scanner;

public class Administador 
{
	static Scanner scanner = new Scanner(System.in);
	
	public static void ModoAdmin() 
	{
		String ClaveAdmin;
		
		System.out.println("");
		System.out.println("==================================");
		System.out.println("=========ADMINISTRADOR============");
		System.out.println("==================================");
		System.out.println("");
		
		System.out.println("ESCRIBA LA CONTRASE�A");
		ClaveAdmin = scanner.nextLine();
		
		if (ClaveAdmin.equals("Admin"))
		{
			System.out.println("=USTED INGRESO COMO ADMINISTRADOR=");
			
			System.out.println("==================================");
			System.out.println("===INFORME DE RESERVAS GENERADO===");
			System.out.println("==================================");
			System.out.println("");
		}
		else 
		{
			System.out.println("");
			System.out.println("========CLAVE INCORRECTA==========");
			System.out.println("===REGRESANDO AL MENU PRINCIPAL===");
			System.out.println("");
			
			/*
			System.out.println("Nombre:       " + Cliente.Nombre);
	   		System.out.println("Edad:         " + Cliente.Edad);
	   		System.out.println("Cedula:       " + Cliente.Cedula);
	   		System.out.println("Direccion     " + Cliente.Direccion);
	   		System.out.println("Telefono:     " + Cliente.Telefono);
	   		System.out.println("ID de cliente:" + Cliente.IDCliente);
	   		System.out.println("Reservas:     " + Cliente.ReservasCliente);
	   		*/
		}
	}

}
