package clases;

import java.util.Scanner;

public class Vehiculo 
{

static Scanner scanner = new Scanner(System.in);
	
	static String Modelo;
	static String TipoDeVehiculo;
	static String Color;
	static String Marca;
	static String Matricula;
	static String GarajeAsignado; //Falta asignarlo
	static String AgenciaAsignada;
	static boolean Disponiblidad;
	static String CapacidadCombustible;
	static boolean VerFichaTecnica; //Falta crearla
	static int PrecioReserva;
	static boolean ConfirmarReserva;
	
	public static void Montero()
	{
		Modelo = "Montero Sport 3.0 2020";
		TipoDeVehiculo = "Camioneta";
		Color = "Gris";
		Marca = "Mitsubishi";
		Matricula = "POG-444";
		GarajeAsignado = "A-01";
		CapacidadCombustible = "100L";
		PrecioReserva = 135000;
		Disponiblidad = true;
		VerFichaTecnica = true;
		ConfirmarReserva = false;
		AgenciaAsignada = "Tattoine";
		
		System.out.println("Modelo:" + Modelo);
		System.out.println("Tipo:" + TipoDeVehiculo);
		System.out.println("Color:" + Color);
		System.out.println("Marca:" + Marca);
		System.out.println("Matricula:" + Matricula);
		System.out.println("GarajeAsignado:" + GarajeAsignado);
		System.out.println("Capacidad de Combustible:" + CapacidadCombustible);
		System.out.println("Precio Reserva:" + PrecioReserva + "$ Por dia");
		System.out.println("Agencia:" + Modelo);
		
		FichaTecnica.FichaA1();
		
		if (Disponiblidad == true) 
        {  
        System.out.println("Disponiblidad: Disponible");  
        } else if (Disponiblidad == false) 
        {  
        System.out.println("Disponiblidad: Reservado");  
        }
		
		System.out.println("Deseas reservar este carro? Escriba true o false");
		boolean ConfirmarReserva = scanner.nextBoolean();  
		if (ConfirmarReserva == true)
		{
			System.out.println("RESERVASTE ESTE CARRO");
		}			
		else if (ConfirmarReserva == false) 
        {  
			System.out.println("REGRESANDO A LA AGENCIA");  
        }
	}	
	
	public static void Camaro()
	{
		Modelo = "Camaro SS 1967";
		TipoDeVehiculo = "Deportivo";
		Color = "Rojo";
		Marca = "Chevrolet";
		Matricula = "FAQ-771";
		GarajeAsignado = "A-02";
		CapacidadCombustible = "75L";
		PrecioReserva = 250000;
		Disponiblidad = true;
		VerFichaTecnica = true;
		ConfirmarReserva = false;
		AgenciaAsignada = "Tattoine";
		
		
		System.out.println("Modelo:" + Modelo);
		System.out.println("Tipo:" + TipoDeVehiculo);
		System.out.println("Color:" + Color);
		System.out.println("Marca:" + Marca);
		System.out.println("Matricula:" + Matricula);
		System.out.println("GarajeAsignado:" + GarajeAsignado);
		System.out.println("Capacidad de Combustible:" + CapacidadCombustible);
		System.out.println("Precio Reserva:" + PrecioReserva + "$ Por dia");
		System.out.println("Agencia:" + Modelo);
		
		FichaTecnica.FichaA2();
		
		if (Disponiblidad == true) 
        {  
        System.out.println("Disponiblidad: Disponible");  
        } else if (Disponiblidad == false) 
        {  
        System.out.println("Disponiblidad: Reservado");  
        }
		
		System.out.println("Deseas reservar este carro? Escriba true o false");
		boolean ConfirmarReserva = scanner.nextBoolean();  
		if (ConfirmarReserva == true)
		{
			System.out.println("RESERVASTE ESTE CARRO");
		}			
		else if (ConfirmarReserva == false) 
        {  
			System.out.println("REGRESANDO A LA AGENCIA");  
        }
	}
	
	public static void Mazda() 
	{
		Modelo = "Mazda 3 Sedan 2.0L Prime 2021 ";
		TipoDeVehiculo = "Sedan";
		Color = "Negro";
		Marca = "Mazda";
		Matricula = "LIL-212";
		GarajeAsignado = "B-01";
		CapacidadCombustible = "67L";
		PrecioReserva = 60000;
		Disponiblidad = true;
		VerFichaTecnica = true;
		ConfirmarReserva = false;
		AgenciaAsignada = "Curust";
		
		System.out.println("Modelo:" + Modelo);
		System.out.println("Tipo:" + TipoDeVehiculo);
		System.out.println("Color:" + Color);
		System.out.println("Marca:" + Marca);
		System.out.println("Matricula:" + Matricula);
		System.out.println("GarajeAsignado:" + GarajeAsignado);
		System.out.println("Capacidad de Combustible:" + CapacidadCombustible);
		System.out.println("Precio Reserva:" + PrecioReserva + "$ Por dia");
		
		FichaTecnica.FichaB1();
		
		if (Disponiblidad == true) 
        {  
        System.out.println("Disponiblidad: Disponible");  
        } else if (Disponiblidad == false) 
        {  
        System.out.println("Disponiblidad: Reservado");  
        }
		
		System.out.println("Deseas reservar este carro? Escriba true o false");
		boolean ConfirmarReserva = scanner.nextBoolean();  
		if (ConfirmarReserva == true)
		{
			System.out.println("RESERVASTE ESTE CARRO");
		}			
		else if (ConfirmarReserva == false) 
        {  
			System.out.println("REGRESANDO A LA AGENCIA");  
        }
		
	}

	public static void Jeep()
	{
		Modelo = "Wrangler 2022";
		TipoDeVehiculo = "Camioneta";
		Color = "Negro";
		Marca = "Jeep";
		Matricula = "JEP-153";
		GarajeAsignado = "B-02";
		CapacidadCombustible = "80L";
		PrecioReserva = 100000;	
		Disponiblidad = true;
		VerFichaTecnica = true;
		ConfirmarReserva = false;
		AgenciaAsignada = "Curust";
		
		System.out.println("Modelo:" + Modelo);
		System.out.println("Tipo:" + TipoDeVehiculo);
		System.out.println("Color:" + Color);
		System.out.println("Marca:" + Marca);
		System.out.println("Matricula:" + Matricula);
		System.out.println("GarajeAsignado:" + GarajeAsignado);
		System.out.println("Capacidad de Combustible:" + CapacidadCombustible);
		System.out.println("Precio Reserva:" + PrecioReserva + "$ Por dia");
		
		FichaTecnica.FichaB2();
		
		if (Disponiblidad == true) 
        {  
        System.out.println("Disponiblidad: Disponible");  
        } else if (Disponiblidad == false) 
        {  
        System.out.println("Disponiblidad: Reservado");  
        }
		
		System.out.println("Deseas reservar este carro? Escriba true o false");
		boolean ConfirmarReserva = scanner.nextBoolean();  
		if (ConfirmarReserva == true)
		{
			System.out.println("RESERVASTE ESTE CARRO");
		}			
		else if (ConfirmarReserva == false) 
        {  
			System.out.println("REGRESANDO A LA AGENCIA");  
        }
	}
	
	
}
