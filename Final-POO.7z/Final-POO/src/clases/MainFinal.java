package clases;
import java.util.Scanner;

public class MainFinal
{
	

	static Scanner scanner = new Scanner(System.in);	
	static int OpcionMain = -1;

	public static void main(String[] args) 
	{
		while(OpcionMain !=0) 
		{			try 
			{						
			
			System.out.println("==================================");
			System.out.println("==========MENU PRINCIPAL==========");
			System.out.println("==================================");
			System.out.println("1. Presione 1 para registrarse");
			System.out.println("2. Presione 2 para administrador");
			System.out.println("3. Presione 3 para Reservar un carro");
			System.out.println("4. Presione 4 para ver informacion de cliente");
			System.out.println("0. Presione 0 para salir");
			
			// TEST System.out.println(Cliente.IDCliente);
			
			OpcionMain = Integer.parseInt(scanner.nextLine());
			
				switch(OpcionMain)
				{
				case 1:					
					Cliente.Registro();
					break;
				case 2:
					Administador.ModoAdmin();
					break;
				case 3:
					Reserva.RegistrarReserva();
					break;
				case 4:
					Cliente.InfoCliente();
					break;
				case 0:
					System.out.println("Sesion Cerrada");
					break;
				default:
					System.out.println("Opcion invalida");
				}
			}
			catch(Exception e) 
			{
				System.out.println("Error!");
			}
		}
	}

}
