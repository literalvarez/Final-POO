package clases;
import java.util.Scanner;

public class Agencia
{
	
	static Scanner scanner = new Scanner(System.in);
	
	static String nombreAgencia; 
	static String dirreccionAgencia;
	static int centroDeCostos; //ID de la Agencia
	static int garajesAsignados;
	static int opcionAgencia = -1;
	
	public Agencia() {
		
		nombreAgencia = "";
		dirreccionAgencia = "";
		centroDeCostos = 0;
		garajesAsignados = 0;
	}
	
	public static void AgenciaTattoine () 
	{		
		nombreAgencia = "Pods deportivos De Tattoine";
		dirreccionAgencia = "Calle Mos Espa #14 Sur, Borde Exterior";
		centroDeCostos = 000001;
		garajesAsignados = 02;
		
		System.out.println("");
	   	System.out.println("=====Informaci�n de la Agencia====");
	   	System.out.println("");
	  	System.out.println("Nombre:            " + nombreAgencia);
	   	System.out.println("Direcci�n:         " + dirreccionAgencia);
	   	System.out.println("Centro de Cosotos: " + centroDeCostos);
	   	System.out.println("N�mero de Garajes  " + garajesAsignados);
	   	
	   	while (opcionAgencia != 0) 
		{			
			try 
			{
			System.out.println("==================================");
			System.out.println("=========Agencia Tattoine=========");
			System.out.println("==================================");
			System.out.println("1. Presione 1 para ver Montero Mitsubishi");
			System.out.println("2. Presione 2 para ver Chevrolet Camaro");
			System.out.println("3. Para regresar a seleccion de agencias");
			opcionAgencia = Integer.parseInt(scanner.nextLine());
				
			switch(opcionAgencia)
				{
				case 1:					
					Vehiculo.Montero(); 
					break;
				case 2:
					Vehiculo.Camaro();
					break;
				case 3:
					Reserva.SeleccionAgencia();
					break;
				case 0:
					System.out.println("Reserva Cancelada");
					break;
					
				default:
					System.out.println("Opcion invalida");
				}
			}
			catch(Exception e) 
			{
				System.out.println("Error!");
			}
		}
	   	
	}
	
	public static void AgenciaCurust () 
	{
		
		nombreAgencia = "Rep�blica Gal�ctica";
		dirreccionAgencia = "Calle Orden #66 -Distito del Senado, N�cleo Interior";
		centroDeCostos = 000066;
		garajesAsignados = 02;
		
		System.out.println("");
	   	System.out.println("=====Informaci�n de la Agencia====");
	   	System.out.println("");
	  	System.out.println("Nombre:            " + nombreAgencia);
	   	System.out.println("Direcci�n:         " + dirreccionAgencia);
	   	System.out.println("Centro de Cosotos: " + centroDeCostos);
	   	System.out.println("N�mero de Garajes  " + garajesAsignados);	   	
	   	
	   	while (opcionAgencia != 0) 
		{			
			try 
			{
			System.out.println("==================================");
			System.out.println("==========Agencia Curust==========");
			System.out.println("==================================");
			System.out.println("1. Presione 1 para ver Mazda Mazda 3");
			System.out.println("2. Presione 2 para Jeep Wrangler");
			System.out.println("3. Para regresar a seleccion de agencias");
			opcionAgencia = Integer.parseInt(scanner.nextLine());
				
			switch(opcionAgencia)
				{
				case 1:					
					Vehiculo.Mazda(); 
					break;
				case 2:
					Vehiculo.Jeep();
					break;
				case 3:
					Reserva.SeleccionAgencia();
					break;
				case 0:
					System.out.println("Reserva Cancelada");
					break;
					
				default:
					System.out.println("Opcion invalida");
				}
			}
			catch(Exception e) 
			{
				System.out.println("Error!");
			}
		}
	}
}