package clases;
import java.util.Scanner;

public class Reserva {
	
	//Esta pendiente lo de las fechas
	static int idReserva;
	static int valorPorVehiculo;
	//El nombreAgencia se llama de la clase Agencia
	static int precioTotal;
	static int litrosPorVehiculo;
	static boolean fueEntregado;
	static int verIDCliente; //Para verificar si e� ID del Cliente existe 
	static int opcionReserva = -1;
	
	static Scanner scanner = new Scanner(System.in); 
	
	public Reserva() {
	
		idReserva = 0;
		valorPorVehiculo = 0;
		precioTotal = 0;
		litrosPorVehiculo = 0;
		fueEntregado = false;
		verIDCliente = 0;
	}

	// se verifique con el IDCliente aka "ID del Cliente"
	public static void RegistrarReserva() 
	{
		System.out.println("");
		System.out.println("==================================");
		System.out.println("============Reservas==============");
		System.out.println("==================================");
		System.out.println("");
		System.out.println("Antes de empezar tu reserva por favor ");
		System.out.println("Ingresa tu ID de Cliente: ");
		verIDCliente = Integer.parseInt(scanner.nextLine());
		
		if (verIDCliente == Cliente.IDCliente) 
		{
			SeleccionAgencia();
		}
		else {
			System.out.println("Su Usuario a�n no ha sido registrado.");
			System.out.println("Por favor intentelo de nuevo");
		}
	}
	
	public static void SeleccionAgencia()
	{
		while (opcionReserva != 0) 
		{			
			try 
			{
			System.out.println("==================================");
			System.out.println("=======Agencias Disponibles=======");
			System.out.println("==================================");
			System.out.println("1. Presione 1 para Pods de Tattoine");
			System.out.println("2. Presione 2 para Agencia Curust");
			System.out.println("0. Presione 0 para volver al Menu Principal");
			opcionReserva = Integer.parseInt(scanner.nextLine());
				
			switch(opcionReserva)
				{
				case 1:					
					Agencia.AgenciaTattoine(); 
					break;
				case 2:
					Agencia.AgenciaCurust();
					break;
				case 0:
					System.out.println("Reserva Cancelada");
					break;
				default:
					System.out.println("Opcion invalida");
				}
			}
			catch(Exception e) 
			{
				System.out.println("Error!");
			}
		}
	}
}
